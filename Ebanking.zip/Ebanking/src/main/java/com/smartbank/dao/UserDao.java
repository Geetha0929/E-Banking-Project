package com.smartbank.dao;

import java.util.List;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.query.Query;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.Account;
import com.smartbank.model.Customer;
import com.smartbank.model.User;

public class UserDao {
     @Autowired
     
     private SessionFactory sessionFactory;
     
     public String validate(User user){
    	
    	 Session session = sessionFactory.openSession();
    	 String hql = "from logintable where uname=:unam and pwd=:password";
    	Query query =session.createQuery(hql);
    	query.setParameter("unam", user.getUname());
    	query.setParameter("password", user.getPwd());
    	
    	
    	 List list = query.getResultList();
    	
    	 if(list.size()==0)
    		 return "failure";
    	 else 
    		 return "success";
    	
    	
    	  }
}
     
     
     /*
     public long addCustomer(Customer customer,Account account)
     {
    	 Random r = new Random();
    	 Session session=sessionFactory.openSession();
    	 Transaction tx=session.beginTransaction();
    	 long num =(long)r.nextInt(10000000);
    	 Long acc=(long)r.nextInt(1000);
    	 
    	 String acno="12345678901"+acc.toString();
    	 System.out.println("gen "+num);
    	 customer.setId(num);
    	 account.setCustId(customer);
    	 account.setAcctNo(Long.parseLong(acno));
    	 account.setAcctType(accType);
    	 long i=(long)session.save(account);
    	 tx.commit();
    	 session.close();
    	 return i;
     }
 }*/
