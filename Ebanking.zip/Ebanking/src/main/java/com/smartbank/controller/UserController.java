package com.smartbank.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.smartbank.model.Account;
import com.smartbank.model.Customer;
import com.smartbank.model.User;
import com.smartbank.service.UserService;

@Controller
public class UserController {
	
	@Autowired 
	Account account;
	
  @RequestMapping("loginpage")
  public String login(Model m)
	{
		
		m.addAttribute("userBean", new User());
		return "login";
	}

	@RequestMapping(value="/formvalidation", method = RequestMethod.POST)
	public String validate( @ModelAttribute("userBean")User user,Model m)
	{
		String res=UserService.validate(user);
		 if (res.equals("success"))
			
             return "homepage";
			
	 else
	 {
	  return "failure";
	}
	}
	

@RequestMapping("CreateCustomerAccount")
public String createcustomer(Model m){
	m.addAttribute("customerBean",new Customer());
	return "AccountCreation";
	
}

@RequestMapping(value="/acctcreation", method = RequestMethod.POST)
public String acctcreation(@Valid @ModelAttribute("validation")Customer customer,BindingResult result,Model m)
{
	 if (result.hasErrors())
		 {
         return "AccountCreation";
		 }
	 else{
		 return"AcctCreationSuccess";
		
		 
		 
		 
		 //long i = customerService.addCustomer(customer,account,accType);
		 //m.addAttribute("acc",i);
		 //m.addAttribute("id",customer.getId());
		 //return "AcctCreationSuccess";
	 }
}

}


