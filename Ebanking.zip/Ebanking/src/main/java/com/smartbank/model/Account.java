package com.smartbank.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Account")
public class Account {
	
	@Id
	@Column(name="accno")
	private long accNo;
	public long getAccNo() {
		return accNo;
	}
    public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
    public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	private String accType;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="custid",unique=true)
	private Customer custId;
	public Customer getCustId() {
		return custId;
	}
	public void setCustId(Customer custId) {
		this.custId = custId;
	}
	}

