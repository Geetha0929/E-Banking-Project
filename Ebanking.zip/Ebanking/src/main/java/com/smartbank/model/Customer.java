package com.smartbank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.*;

@Entity
@Table(name="customer")
public class Customer {
	@Column(name="firstName",nullable=false)
	private String firstname;
	
	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
		
	}


	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}

	public String getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	@Column(name="lastName",nullable=false)
	 String lastname;
	
	@Column(name="age",nullable=false)
	@Max(99)
	 int age;
	

	@Column(name="gender",nullable=false)
	 String Gender;

	@Column(name="city",nullable=false)
	 String city;

	@Column(name="occupation",nullable=false)
	 String occupation;

	@Column(nullable=false)
	//@pattern"[0-9]{10}"
	@Max(value=10,message="number should not be greater than 10")
	 String contactnumber;

	@Column(nullable=false)
	 String accounttype;
	public Customer() {
	}
	
}
