package com.smartbank.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.Account;
import com.smartbank.model.Customer;
import com.smartbank.model.User;
import com.smartbank.dao.UserDao;

public class UserService {
  @	Autowired
static
  UserDao userDao;
  
  
 
  
    
  
  
  public static String validate(User user)
     {
    	 String s = userDao.validate(user);
    	 return s;
     }
    
     
     
     
     
     
     
     
     
     
     
     
     
     /*
     public long addCustomer(Customer customer,Account account)
     {
    	 long i=userDao.addCustomer(customer,account);
    	 return i;
     
     */

}
